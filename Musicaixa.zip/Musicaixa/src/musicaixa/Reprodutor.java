
package musicaixa;
import java.io.File;
import java.io.IOException;
import javax.sound.midi.Sequence;
import org.jfugue.midi.MidiFileManager;
import org.jfugue.player.ManagedPlayer;
import org.jfugue.player.Player;
 
/**
 * 
 * @author Gabriel
 */
public class Reprodutor {
    private ManagedPlayer tocador = new ManagedPlayer();;
    private Sequence sequencia;
    private Player tocando = new Player();
    private String musica;
    private CriadorDeMusica criador = new CriadorDeMusica();
   
    private final String ERRO_INICIO="Erro ao iniciar a tocar.";
    /**
     *Começa/recomeça a tocar a música.
     */
    public void toca(){
        if(tocador.isFinished() == false){
            if(tocador.isPlaying() == false){
                System.out.println("Entrei aqui por engano");
                tocador.resume();
            }
        }
        else{
            if(tocador.isFinished()){
                tocador.reset();
            }
            try {
                tocador.start(sequencia);
            } catch (Exception ex) {
                System.out.println(ERRO_INICIO);
            }
            
            
       }
    }

    /**
     *Pausa a música se ela estiver tocando.
     */
    public void pausa(){
        if(tocador.isPaused()==false)
            tocador.pause();
    }
    
    /**
     *Carrega a música de um <a href="https://docs.oracle.com/javase/7/docs/api/java/io/File.html"><tt>File</tt></a> fornecido,
     * este deve ser do formato .txt e estar na codificação <i>Staccato</i>.
     * @param arquivo <a href="https://docs.oracle.com/javase/7/docs/api/java/io/File.html"><tt>File</tt></a> .txt com a música 
     * em <i>Staccato</i>.
     */
    public void carregaDeArquivo(File arquivo){
        ManipuladorDeArquivos leitor = new ManipuladorDeArquivos();
        String texto=leitor.lerArquivo(arquivo);
        carregaMusica(texto);        
        
               
    }

    /**
     *Carrega a música de uma <a href="http://docs.oracle.com/javase/7/docs/api/java/lang/String.html"><tt>String</tt></a> fornecida,
     * esta deve estar na codificação <i>Staccato</i>.  
     * @param texto <a href="http://docs.oracle.com/javase/7/docs/api/java/lang/String.html"><tt>String</tt></a> da música em <i>
     * Staccato</i>.
     */
    public void carregaMusica(String texto){
        CriadorDeMusica criador = new CriadorDeMusica();
        criador.montaMusica(texto);
        musica=criador.getSom();
        sequencia = tocando.getSequence(musica);
        tocador.finish();
    }
    
    /**
     * Retorna a sequência
     * @return um objeto do tipo Sequence
     */
    public Sequence getSequencia(){
        return sequencia;
    }    
   
}