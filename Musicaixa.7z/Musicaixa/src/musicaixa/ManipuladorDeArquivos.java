package musicaixa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.sound.midi.Sequence;
import org.jfugue.midi.MidiFileManager;

/**
 * Classe especializada em manipular arquivos de texto e MIDI
 * @author lsrsampaio
 */
public class ManipuladorDeArquivos{
  private BufferedReader leitor_arquivo;
  private String texto_lido;
  private String nomeDoArquivo;
  
  private final String NAO_ACHADO="Arquivo não encontrado!";
  private final String ERRO_LEITURA="Erro ao ler arquivo de texto!";
  private final String ERRO_FECHAR="Erro ao fechar arquivo!"; 
  
  /**
    * Lê o <a href="https://docs.oracle.com/javase/7/docs/api/java/io/File.html"><tt>File</tt></a> de texto fornecido, e 
    * retorna uma <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/String.html"><tt>String</tt></a> contendo o conteúdo do arquivo.
    * @param arquivo  <a href="https://docs.oracle.com/javase/7/docs/api/java/io/File.html"><tt>File</tt></a> .txt contendo a música
    * @return <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/String.html"><tt>String</tt></a> na codificação <i> Staccato </i>
    */
  public String lerArquivo(File arquivo){
      String texto_buffer;
      texto_lido="";
      try {
          leitor_arquivo = new BufferedReader(new FileReader(arquivo));
          while((texto_buffer=leitor_arquivo.readLine())!=null){
              texto_lido+=texto_buffer;
          }
      } catch (FileNotFoundException ex) {
            System.out.println(NAO_ACHADO);
      } catch (IOException ex) {
          System.out.println(ERRO_LEITURA);
      }
      try {
          leitor_arquivo.close();
      } catch (IOException ex) {
          System.out.println(ERRO_FECHAR);
      }
      return texto_lido;
  }
  
  private final String ERRO_SALVAR="Houve um erro ao salvar a musica em um arquivo."; 
   /**
     *Salva a musica atual no <a href="https://docs.oracle.com/javase/7/docs/api/java/io/File.html"><tt>File</tt></a> fornecido,
     * utilizando a codificação MIDI.
     * @param arquivo <a href="https://docs.oracle.com/javase/7/docs/api/java/io/File.html"><tt>File</tt></a> onde será salva a 
     * música.
     * @param sequencia é música que será salva
     */
    public void salvarMusica(File arquivo, Sequence sequencia){
        try {
            MidiFileManager.save(sequencia, arquivo);
        } catch (IOException ex) {
            System.out.println(ERRO_SALVAR);
        }
    }
 
}
