
package musicaixa;

/**
 *
 * @author gsniemiec
 */
public class Nota{
    private final int OITAVA_DEFAULT=3;
    private final char NOTA_DEFAULT='C';
    private final int VOLUME_DEFAULT=30;
    private final int INSTRUMENTO_DEFAULT=1;
    
    
    private char nota;
    private int oitava;
    private int volume;
    private int instrumento;

    /**
     *Inicializa <tt>Nota</tt> com valores <i>default</i>, a ver:
     * <p>nota: C</p>
     * <p>oitava: 3</p>
     * <p>volume: 30</p>
     * <p>instrumento: 1 (piano)</p>
     */
    public Nota() {
        nota=NOTA_DEFAULT;
        oitava=OITAVA_DEFAULT;
        volume=VOLUME_DEFAULT;
        instrumento=INSTRUMENTO_DEFAULT;
    }
    

    private String getVolume() {
        return String.format("a%d", volume);
    }
    private final int VOLUME_MAXIMO=100;

    /**
     * Aumenta o volume da Nota em 10%, até um máximo de 100.
     */
    public void aumentaVolume()
    {
       if(volume<VOLUME_MAXIMO)
            volume+=VOLUME_MAXIMO*0.1;
    }
    
    /**
     *Dobra o volume, saturando no volume máximo de 100.
     */
    public void dobraVolume()
    {
        volume *= 2;
        if(volume>VOLUME_MAXIMO)
            volume=VOLUME_MAXIMO;
    }
    @Override
    public String toString(){
        return String.format("%s %c%d%s ", getInstrumento(), getNota(), getOitava(), getVolume());
    }
    private final int VALOR_MAXIMO_INSTRUMENTO=127;
    /**
     *Seta o instrumento de acordo com a tabela de codificação de instrumentos MIDI.
     * @param instrumento Valor int correspondente ao instrumento.
     */
    public void setInstrumento(int instrumento) {
        if(instrumento<=VALOR_MAXIMO_INSTRUMENTO&&instrumento>=0)
        this.instrumento = instrumento;
    }
    
    private String getInstrumento() {
        return String.format("I%d", this.instrumento);
    }
    
    /**
     *Seta o instrumento por meio de um deslocamento em relação ao instrumento atual 
     * fornecido como parâmetro, de acordo com a tabela de codificação de instrumentos 
     * MIDI.
     * @param deslocamento Valor int a deslocar o valor do instrumento.
     */
    public void somaInstrumento(int deslocamento) {
        instrumento+=deslocamento;
        if(instrumento>VALOR_MAXIMO_INSTRUMENTO)
            instrumento -= VALOR_MAXIMO_INSTRUMENTO+1;
    }

    private char getNota() {
        return nota;
    }

    private int getOitava() {
        return oitava;
    }
    
    private final char PRIMEIRA_NOTA='A';
    private final char ULTIMA_NOTA='G';
    private final char PAUSA='R';

    /**
     *Seta a nota (letras maiúsculas de A a G) ou pausa(R).
     * @param nota char da nota
     */
    public void setNota(char nota) {
        if((nota>=PRIMEIRA_NOTA && nota<=ULTIMA_NOTA)||nota==PAUSA)
            this.nota = nota;
    }
    
    private final int OITAVA_MAXIMA=9;
    /**
     *Aumenta a oitava em 1 (até um máximo de 9). Ao chegar em 9, volta ao valor
     * <i>default</i> (3).
     */
    public void aumentaOitava() {
        if (oitava < OITAVA_MAXIMA)
        {
            oitava = oitava + 1;
        }else{
            oitava=OITAVA_DEFAULT;
        }
    }
}